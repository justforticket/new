var mpUrl = "mp.yeepay.com";


var cashierUrl = "bc-cashier/bcnewpc";

// 注意，必须设置了run_at=document_start 此段代码才会生效
document.addEventListener('DOMContentLoaded', function () {
    // 注入自定义JS
    injectCustomJs();

    var currentHref = window.location.href;
    if (currentHref.indexOf(mpUrl) != -1) {
        //如果是mp,注入mp中js
        // cLog("开始注入mp");
        // injectJs("mp.js");
        // initMp();
        var lastLoginElement = document.getElementById("lastLogin");
        if (lastLoginElement) {
            console.log("登陆成功了的,保持session")
            chrome.runtime.sendMessage({action: "keepSession", bankId: "ALL"}, function (response) {

            });
        } else {
            console.log("登陆没有成功,不保持session")
        }
    } else if (currentHref.indexOf(cashierUrl) != -1) {
        // cLog("开始注入cashier");
        // injectJs("cashier.js");
        // initCashier();
    }
});

function cLog(msg) {
    console.log("支付助手:" + msg);
}

// 向页面注入JS
function injectCustomJs(jsPath) {
    var jsPath = jsPath || 'js/inject.js';
    var temp = document.createElement('script');
    temp.setAttribute('type', 'text/javascript');
    // 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
    temp.src = chrome.extension.getURL(jsPath);
    temp.onload = function () {
        // 放在页面不好看，执行完后移除掉
        this.parentNode.removeChild(this);
    };
    document.body.appendChild(temp);
}

function injectJs(jsName) {
    var jsPath = 'js/' + jsName;
    var temp = document.createElement('script');
    temp.setAttribute('type', 'text/javascript');
    // 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
    temp.src = chrome.extension.getURL(jsPath);
    temp.onload = function () {
        // 放在页面不好看，执行完后移除掉
        // this.parentNode.removeChild(this);
    };
    document.body.appendChild(temp);
}


var listener = function (request, sender, sendResponse) {
    if (request.cmd == "cashierPay") {
        console.log("收到获取卡号消息");
        getCardInfoAndPay();
    }
};
chrome.runtime.onMessage.addListener(listener);

function getCardInfoAndPay() {
    chrome.runtime.sendMessage({action: "getCardInfo", bankId: "ALL"}, function (response) {
        console.log(response);
        if (response.responseData) {
            console.log("获取卡号等结果为:" + response.responseData);
            var result = JSON.parse(response.responseData);
            if (result.getCardInfoCode == true) {
                var data = result;
                if (data != null) {
                    var cardNo = data["cardNo"];
                    var cvv = data["cvv"];
                    var expiryDate = data["expiryDate"];
                    var idCardNo = data["idCardNo"];
                    var userName = data["userName"];
                    var phone = data["phone"];
                    executePay(cardNo, cvv, expiryDate, phone, idCardNo, userName, "true")
                } else {
                    alert(result.getCardInfoMsg)
                }
            } else {
                alert(result.getCardInfoMsg)
            }
        } else {
            alert("错误,请检查是否登录后台")
        }
    });
}

function executePay(cardNo, cvv, expireDate, phone, idCardNo, userName, auto) {
    //获取所有的h2元素
    var h2s = $("body > div > h2");
    for (var i = 0; i < h2s.length; i++) {
        var h2 = h2s[i];
        if ("无卡支付" == h2.innerHTML) {
            h2.classList.add("active");
        } else {
            h2.classList.remove("active");
        }
    }
    //填写账号并点击下一步
    var cardInput = $("form .sington input[name=cardno]");
    cardInput.attr("value", cardNo);
    simulateEvent(cardInput, "input");
    $("#quickPayForm > button")[0].click();

    var clicked = false;
    $("#addItemWrapper").bind("DOMNodeInserted", function (e) {
            var finishCount = 0;
            if ("储蓄卡" == $.trim($(".card-bin .card-type").text())) {
                console.log("确认为储蓄卡,不支持自动导入");
            } else {
                // console.log("确认为信用卡");
                tryInputThreeTimes(cardNo, cvv, expireDate, phone, idCardNo, userName, auto, submitRequest);
            }
        }
    )

    function simulateEvent(cb, event) { //js触发事件--事件构造器
        var evt = document.createEvent("Event");
        evt.initEvent(event, true, true);
        var canceled = !cb[0].dispatchEvent(evt);
        if (canceled) {
            // A handler called preventDefault
            // console.log("canceled");
        } else {
            // None of the handlers called preventDefault
            // console.log("not canceled");
        }
    }

    function simulateEventClick(id, event) { //js触发事件--事件构造器
        var evt = document.createEvent("Event");
        evt.initEvent(event, true, true);
        var button = document.getElementById(id);
        var canceled = !button.dispatchEvent(evt);
        if (canceled) {
            // A handler called preventDefault
            // console.log("canceled");
        } else {
            // None of the handlers called preventDefault
            // console.log("not canceled");
        }
    }

    function tryInputThreeTimes(cardNo, cvv, expireDate, phone, idCardNo, userName, auto, callbackSubmit) {
        for (var i = 0; i < 3; i++) {
            //尝试三次设置值
            checkInputValue("name", userName);
            checkInputValue("idno", idCardNo);
            checkInputValue("valid", expireDate);
            checkInputValue("cvv2", cvv);
            checkInputValue("phone", phone);
        }
        callbackSubmit(auto);
    }

    function checkInputValue(key, value) {
        if ($("form input[name='" + key + "']").attr("value") != value) {
            // console.log(key + "还为空")
            $("form input[name='" + key + "']").attr("value", value);
            return 0;
        } else {
            return 1;
        }
    }

    function submitRequest(auto) {
        if (clicked) {
            return;
        }
        clicked = true;
        if ("false" == auto) {

        } else {
            setTimeout(
                function () {
                    console.log("准备支付")
                    $("#firstPayBtn").click();
                    simulateEventClick("firstPayBtn", "click");
                }
                , 1000);//延时3秒
        }
    }
}