function initShow() {
    var datas = localStorage.userInfo;
    if (datas) {
        datas = JSON.parse(datas);
        console.log(datas);
        var tab = document.getElementById('tab');
        for (var i = 0, dataLength = datas.length; i < dataLength; i++) {
            var data = datas[i];
            var id = Math.random();
            var tabAdd = tab.insertRow(1);
            tabAdd.innerHTML = '<tr>' +
                '<th scope="row">用户</th>\n' +
                '<td><input type="text" value="' + data[0] + '"/></td>\n' +
                '<td><input type="text" value="' + data[1] + '"/></td>\n';
            if ('checked' == data[2]) {
                tabAdd.innerHTML += '<td><input type="checkbox" checked style="width: auto;height: auto"/></td>\n';
            } else {
                tabAdd.innerHTML += '<td><input type="checkbox" style="width: auto;height: auto"/></td>\n';
            }
            tabAdd.innerHTML += '<td id="' + id + '">\n' +
                '    <button onclick="deleteRow(' + id + ')">删除</button>\n' +
                '</td>\n' +
                '</tr>';
            addAction(id);
        }
    }
}

initShow();


document.getElementById('save').onclick = function () {
    var myTable = document.getElementById('tab');
    var data = [];
    for (var i = 1, rows = myTable.rows.length; i < rows; i++) {
        for (var j = 1, cells = myTable.rows[i].cells.length; j < cells; j++) {
            var vs = myTable.rows[i].cells[j];
            if (vs.getElementsByTagName("input").length > 0) {
                var checkboxType = vs.getElementsByTagName("input")[0].getAttribute("type");
                if (checkboxType == 'checkbox') {
                    if (vs.getElementsByTagName("input")[0].checked) {
                        vs = "checked";
                    } else {
                        vs = "unchecked";
                    }
                } else {
                    vs = vs.getElementsByTagName("input")[0].value;
                }
                if (!data[i - 1]) {
                    data[i - 1] = new Array();
                }
                data[i - 1][j - 1] = vs;
            }
        }
    }

    localStorage.userInfo = JSON.stringify(data);
    alert('保存成功。');
}

document.getElementById('add').onclick = function () {
    var tab = document.getElementById('tab');
    var rows = tab.rows; //返回包含表格中所有行的一个数组。
    if (rows.length >= 11) {
        alert("最多只能添加10个用户")
    } else {
        var id = Math.random();
        var tabAdd = tab.insertRow(1);
        tabAdd.innerHTML = '<tr>' +
            '<th scope="row">用户</th>\n' +
            '<td><input type="text"/></td>\n' +
            '<td><input type="text"/></td>\n' +
            '<td><input type="checkbox" style="width: auto;height: auto"/></td>\n' +
            '<td id="' + id + '">\n' +
            '    <button id=' + id + '>删除</button>\n' +
            '</td>\n' +
            '</tr>';
        addAction(id);
    }
};

function addAction(id) {
    document.getElementById(id).addEventListener("click", function () {
        var tab = document.getElementById('tab');
        var rows = tab.rows; //返回包含表格中所有行的一个数组。
        for (var i = 0; i < rows.length; i++) {
            var thisId = rows[i].cells[4].getAttribute("id");
            if (id == thisId) {
                tab.deleteRow(i);
            }
        }
    });
}


// function deleteRow(id) {
//     var tab = document.getElementById('tab');
//     var rows = tab.rows; //返回包含表格中所有行的一个数组。
//     for (var i = 0; i < rows.length; i++) {
//         var thisId = rows[i].cells[5].getAttribute("id");
//         if (id == thisId) {
//             tab.deleteRow(i);
//         }
//     }
// }
